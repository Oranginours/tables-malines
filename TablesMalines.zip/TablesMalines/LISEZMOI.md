# Tables Malines — obtenir l'APK

## Option A : sans rien installer (GitHub, gratuit, ~5 min)
1. Crée un compte sur github.com puis un nouveau dépôt (bouton **New**), par ex. `tables-malines`.
2. Sur la page du dépôt : **Add file → Upload files**, glisse **tout le contenu** de ce dossier
   (y compris le dossier caché `.github` — sur Mac : Cmd+Maj+. pour l'afficher), puis **Commit**.
   Si le dossier `.github` n'a pas été envoyé : **Add file → Create new file**, nomme-le
   `.github/workflows/build-apk.yml` et colle-y le contenu du fichier du même nom.
3. Onglet **Actions** → le build « Construire l'APK » démarre tout seul (≈ 3–4 min).
4. Clique sur le build terminé (✅) → en bas, **Artifacts → TablesMalines-apk** → tu obtiens un .zip contenant `app-debug.apk`.

## Option B : Android Studio
Ouvre ce dossier dans Android Studio → menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
L'APK est dans `app/build/outputs/apk/debug/`.

## Installer sur le téléphone
Copie `app-debug.apk` sur le téléphone (câble, Drive, mail…), ouvre-le,
et autorise « Installer des applis inconnues » quand Android le demande.
Android 8 ou plus récent. L'appli fonctionne hors ligne ; les progrès restent sur le téléphone.

## Utiliser l'appli dans un navigateur, avec le micro (GitHub Pages)
Chrome n'autorise le micro que sur une page en https://, pas sur un fichier ouvert depuis le téléphone.
1. Dans ton dépôt GitHub : **Add file → Upload files** et envoie `app/src/main/assets/index.html` **à la racine** du dépôt.
2. **Settings → Pages** → Source : *Deploy from a branch* → Branch : *main* / *(root)* → **Save**.
3. Après 1 à 2 minutes, l'adresse s'affiche (ex. `https://ton-pseudo.github.io/tables-malines/`).
   Ouvre-la dans Chrome : le micro est demandé au premier appui sur 🎤.
   Menu ⋮ → « Ajouter à l'écran d'accueil » pour l'avoir comme une appli.
